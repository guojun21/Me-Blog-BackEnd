package com.meblog.blog.service;

import com.meblog.blog.vo.Result;
import com.meblog.blog.vo.params.CommentParam;

public interface CommentsService {

    //根据文章id查询所有的评论列表
    Result commentsByArticleId(Long id);

    Result comment(CommentParam commentParam);
}
