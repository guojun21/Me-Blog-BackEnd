package com.meblog.blog.common.cache;


import java.lang.annotation.*;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Cache {

    long expire() default 1 * 60 * 1000;//资源加载到内存中的过期时间，保证只有常访问的资源在内存中

    String name() default "";//缓存标识

}