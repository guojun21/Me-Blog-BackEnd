package com.meblog.blog.service;

import com.meblog.blog.dao.pojo.SysUser;
import com.meblog.blog.vo.Result;
import com.meblog.blog.vo.params.LoginParam;

public interface LoginService {
    //登录功能
    Result login(LoginParam loginParam);



    SysUser checkToken(String token);


    //退出登录
    Result logout(String token);

    //注册
    Result register(LoginParam loginParam);
}
