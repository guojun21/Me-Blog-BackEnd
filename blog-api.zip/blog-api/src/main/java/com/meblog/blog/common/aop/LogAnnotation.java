package com.meblog.blog.common.aop;


import java.lang.annotation.*;
//TYPE代表这个annotation可以放在类里，而method代表它可以放在方法里
@Target({ElementType.TYPE,ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface LogAnnotation {
    String module() default "";
    String operator() default  "";
}
