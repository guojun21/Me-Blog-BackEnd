package com.meblog.blog.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.meblog.blog.dao.dos.Archives;
import com.meblog.blog.dao.mapper.ArticleBodyMapper;
import com.meblog.blog.dao.mapper.ArticleMapper;
import com.meblog.blog.dao.mapper.ArticleTagMapper;
import com.meblog.blog.dao.pojo.Article;
import com.meblog.blog.dao.pojo.ArticleBody;
import com.meblog.blog.dao.pojo.ArticleTag;
import com.meblog.blog.dao.pojo.SysUser;
import com.meblog.blog.service.*;
import com.meblog.blog.utils.UserThreadLocal;
import com.meblog.blog.vo.ArticleBodyVo;
import com.meblog.blog.vo.ArticleVo;
import com.meblog.blog.vo.Result;
import com.meblog.blog.vo.TagVo;
import com.meblog.blog.vo.params.ArticleParam;
import com.meblog.blog.vo.params.PageParams;
import lombok.val;
import org.joda.time.DateTime;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ArticleServiceImpl implements ArticleService {

    @Autowired
    private ArticleMapper articleMapper;
    @Autowired
    private TagService tagService;
    @Autowired
    private SysUserService sysUserService;
    @Autowired
    private ArticleTagMapper articleTagMapper;


    @Override
    public Result listArticle(PageParams pageParams){
        Page<Article> page=new Page<>(pageParams.getPage(), pageParams.getPagesize());
        IPage<Article> articleIPage = articleMapper.listArticle(page,
                pageParams.getCategoryId(),
                pageParams.getTagId(),
                pageParams.getYear(),
                pageParams.getMonth());
        List<Article> records=articleIPage.getRecords();
        return Result.success(copyList(records,true,true));

    }

//    @Override
//    public Result listArticle(PageParams pageParams){
//        //分页查询数据库表得到结果
//        Page<Article> page=new Page<>(pageParams.getPage(), pageParams.getPagesize());
//        LambdaQueryWrapper<Article> queryWrapper=new LambdaQueryWrapper<>();
//        //实现更具文章分类显示文章
//        if(pageParams.getCategoryId()!=null){
//            //category_id=#{category_id}
//            queryWrapper.eq(Article::getCategoryId,pageParams.getCategoryId());
//        }
//
//        List<Long> articleIdList=new ArrayList<>();
//        //实现根据文章标签显示文章
//        if(pageParams.getTagId()!=null){
//            //article表中没有tag字段因为一篇文章可能有多个标签
//            //article_tag表中才有
//            LambdaQueryWrapper<ArticleTag> articleTagLambdaQueryWrapper=new LambdaQueryWrapper<>();
//            articleTagLambdaQueryWrapper.eq(ArticleTag::getTagId,pageParams.getTagId());
//            List<ArticleTag> articleTags = articleTagMapper.selectList(articleTagLambdaQueryWrapper);
//            for (ArticleTag articleTag : articleTags) {
//                articleIdList.add(articleTag.getArticleId());
//            }
//            if(articleIdList.size()>0){
//                queryWrapper.in(Article::getId,articleIdList);
//            }
//        }
//        //是否置顶进行排序
//        //order by create_date desc
//        queryWrapper.orderByDesc(Article::getWeight,Article::getCreateDate);
//        Page<Article> articlePage=articleMapper.selectPage(page,queryWrapper);
//        List<Article> records= articlePage.getRecords();
//        List<ArticleVo> articleVoList=copyList(records,true,true);
//        return Result.success(articleVoList);
//    }

    @Override
    public Result hotArticle(int limit) {

        LambdaQueryWrapper<Article> queryWrapper=new LambdaQueryWrapper<>();
        queryWrapper.orderByDesc(Article::getViewCounts);
        queryWrapper.select(Article::getId,Article::getTitle);
        queryWrapper.last("limit "+limit);
        //select id,title from article order by view_counts desc limit 5
        List<Article> articles = articleMapper.selectList(queryWrapper);
        return Result.success(copyList(articles,false,false));
    }

    @Override
    public Result newArticles(int limit) {
        LambdaQueryWrapper<Article> queryWrapper=new LambdaQueryWrapper<>();
        queryWrapper.orderByDesc(Article::getCreateDate);
        queryWrapper.select(Article::getId,Article::getTitle);
        queryWrapper.last("limit "+limit);
        //select id,title from article order by created_date desc limit 5
        List<Article> articles = articleMapper.selectList(queryWrapper);
        return Result.success(copyList(articles,false,false));
    }

    @Override
    public Result listArchives() {
        List<Archives> archivesList=articleMapper.listArchives();
        return Result.success(archivesList);
    }
    @Autowired
    private ThreadService threadService;

    @Override
    public Result findArticleById(Long articleId) {

        //根据ID查询文章的信息
        //根据bodyId和catagoryid去关联查询
        //

        Article article=this.articleMapper.selectById(articleId);

        ArticleVo articleVo = copy(article, true, true,true,true);
        //查看完文章了，新增阅读数的问题：
        //我们在查看文章后，本应该直接返回数据，这时候做了更新操作，更新时候，要加写锁，阻塞其他的读操作，性能比较低，但是没法解决这个问题，因为是必要的
        //更新增加了本次接口的耗时 如果一旦更新出问题，那么不能影响我们查看文章的操作
        //所以我们用线程池来达到这么一个目的 可以把更新操作扔到线程池执行，那么就与主线程不想管了

        threadService.updateArticleViewCount(articleMapper,article);
        return Result.success(articleVo);
    }

    @Override
    public Result publish(ArticleParam articleParam) {
        //用下面这行的前提是此接口要加入到登录拦截中
        SysUser sysUser = UserThreadLocal.get();
        //1、发布文章，目的是构建article对象
        //2、要作者id，也就是当前登录用户的id
        //3、要将标签加入关联列表中
        //4、文章内容存储 要一个bodyId
        Article article=new Article();
        article.setAuthorId(sysUser.getId());
        article.setWeight(Article.Article_Common);
        article.setViewCounts(0);
        article.setTitle(articleParam.getTitle());
        article.setSummary(articleParam.getSummary());
        article.setCommentCounts(0);
        article.setCreateDate(System.currentTimeMillis());
        article.setCategoryId(Long.parseLong(articleParam.getCategory().getId()));

        //插入之后会生成一个文章ID
        this.articleMapper.insert(article);
        List<TagVo> tags=articleParam.getTags();
        if(tags!=null){
            for(TagVo tag:tags) {
                Long articleId = article.getId();
                ArticleTag articleTag = new ArticleTag();
                articleTag.setTagId(Long.parseLong(tag.getId()));
                articleTag.setArticleId(articleId);
                articleTagMapper.insert(articleTag);
            }
        }
        //body
        ArticleBody articleBody=new ArticleBody();
        articleBody.setArticleId(article.getId());
        articleBody.setContent(articleParam.getBody().getContent());
        articleBody.setContentHtml(articleParam.getBody().getContentHtml());
        articleBodyMapper.insert(articleBody);
        article.setBodyId(articleBody.getId());
        articleMapper.updateById(article);
        Map<String,String> map=new HashMap<>();
        map.put("id",article.getId().toString());
        return Result.success(map);
    }

    private List<ArticleVo> copyList(List<Article> records,boolean isTag, boolean isAuthor) {
        List<ArticleVo> articleVoList=new ArrayList<>();
        for (Article record : records) {
            articleVoList.add(copy(record,isTag,isAuthor,false,false));
        }
        return articleVoList;
    }

    private List<ArticleVo> copyList(List<Article> records,boolean isTag, boolean isAuthor,boolean isBody,boolean isCatagory) {
        List<ArticleVo> articleVoList=new ArrayList<>();
        for (Article record : records) {
            articleVoList.add(copy(record,isTag,isAuthor,isBody,isCatagory));
        }
        return articleVoList;
    }


    @Autowired
    private CategoryService categoryService;


    private ArticleVo copy(Article article, boolean isTag, boolean isAuthor,boolean isBody,boolean isCatagory){
        ArticleVo articleVo=new ArticleVo();
        articleVo.setId(String.valueOf(article.getId()));
        BeanUtils.copyProperties(article,articleVo);

        articleVo.setCreateDate(new DateTime(article.getCreateDate()).toString("yyyy-MM-dd HH:mm"));
        //并不是所有的接口都需要标签和作者信息
        if(isTag){
            Long articleId=article.getId();
            articleVo.setTags(tagService.findTagsByArticleId(articleId));
        }
        if(isAuthor){
            Long authorId = article.getAuthorId();
            articleVo.setAuthor(sysUserService.findUserById(authorId).getNickname());
        }
        if(isBody){
            Long bodyId=article.getBodyId();
            articleVo.setBody(findArticleBodyById(bodyId));
        }
        if(isCatagory){
            Long catagoryId=article.getCategoryId();
            articleVo.setCategory(categoryService.findCategoryById(catagoryId));
        }
        return articleVo;

    }

    @Autowired
    private ArticleBodyMapper articleBodyMapper;


    private ArticleBodyVo findArticleBodyById(Long bodyId) {
        ArticleBody articleBody=articleBodyMapper.selectById(bodyId);
        ArticleBodyVo articleBodyVo=new ArticleBodyVo();
        articleBodyVo.setContent(articleBody.getContent());
        return articleBodyVo;
    }

}
