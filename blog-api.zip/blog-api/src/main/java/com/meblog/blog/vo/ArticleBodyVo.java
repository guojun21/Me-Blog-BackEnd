package com.meblog.blog.vo;

import lombok.Data;

@Data
public class ArticleBodyVo {

    private String content;
}
