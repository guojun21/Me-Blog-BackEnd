package com.meblog.blog.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.meblog.blog.dao.pojo.Comment;

public interface CommentMapper extends BaseMapper<Comment> {
}
