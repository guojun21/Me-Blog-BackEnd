package com.meblog.blog.service;

import com.meblog.blog.dao.pojo.SysUser;
import com.meblog.blog.vo.Result;
import com.meblog.blog.vo.UserVo;

public interface SysUserService {
    UserVo findUserVoById(Long id);
    SysUser findUserById(Long id);

    SysUser findUser(String account, String password);
    //根据token来查询用户信息
    Result findUserByToken(String token);


    //根据账号查找用户
    SysUser findUserByAccount(String account);


    //保存用户
    void save(SysUser sysUser);
}
