package com.meblog.blog.utils;

import com.meblog.blog.dao.pojo.SysUser;

public class UserThreadLocal {

    private UserThreadLocal(){

    }

    private static final ThreadLocal<SysUser> LOCAL=new ThreadLocal<SysUser>();

    public static void put(SysUser sysUser){
        LOCAL.set(sysUser);
    }
    public static SysUser get(){
        return LOCAL.get();
    }

    public static void remove(){
        LOCAL.remove();
    }
}
