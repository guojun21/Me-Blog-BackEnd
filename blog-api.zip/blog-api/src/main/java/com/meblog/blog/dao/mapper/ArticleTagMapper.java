package com.meblog.blog.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.meblog.blog.dao.pojo.ArticleTag;


public interface ArticleTagMapper  extends BaseMapper<ArticleTag> {
}
