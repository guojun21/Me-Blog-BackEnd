package com.meblog.blog.service;

import com.meblog.blog.vo.CategoryVo;
import com.meblog.blog.vo.Result;

public interface CategoryService {
    CategoryVo findCategoryById(Long catagoryId);

    Result findAll();

    Result findAllDetail();

    Result categoryDetailById(Long id);
}
