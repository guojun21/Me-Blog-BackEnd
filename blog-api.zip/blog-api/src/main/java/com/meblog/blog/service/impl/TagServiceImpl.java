package com.meblog.blog.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.meblog.blog.dao.mapper.TagMapper;
import com.meblog.blog.dao.pojo.Tag;
import com.meblog.blog.service.TagService;
import com.meblog.blog.vo.Result;
import com.meblog.blog.vo.TagVo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class TagServiceImpl implements TagService {
    @Autowired
    private TagMapper tagMapper;

    public TagVo copy(Tag tag){
        TagVo tagVo = new TagVo();
        BeanUtils.copyProperties(tag,tagVo);
        tagVo.setId(String.valueOf(tag.getId()));
        return tagVo;
    }
    public List<TagVo> copyList(List<Tag> tagList){
        List<TagVo> tagVoList = new ArrayList<>();
        for (Tag tag : tagList) {
            tagVoList.add(copy(tag));
        }
        return tagVoList;
    }
    @Override
    public List<TagVo> findTagsByArticleId(Long articleId){
        //mybatisplus无法进行多表查询
        List<Tag> tags=tagMapper.findTagsByArticleId(articleId);
        return copyList(tags);
    }

    @Override
    public Result hots(int limit) {
        //标签所拥有的文章数量最多那么就是最热标签
        //根据tag计数，从大到小排列，取前limit个
        List<Long> tagIds=tagMapper.findHotsTagIds(limit);
        if(CollectionUtils.isEmpty(tagIds)){
            return Result.success(Collections.emptyList());
        }
        //需求的是tagId和tagName
        List<Tag> tagList=tagMapper.findTagsByTagIds(tagIds);
        return Result.success(tagList);
    }

    @Override
    public Result findAll() {
        LambdaQueryWrapper<Tag> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.select(Tag::getId,Tag::getTagName);
        List<Tag> tags=this.tagMapper.selectList(queryWrapper);

        return Result.success(copyList(tags));//为啥要转：就是tag是与数据库映射的对象，tagVo是与前端映射的对象，相当于再次封装
        //将来不在一个工程里的时候也更好拆分
    }

    @Override
    public Result findAllDetail() {
        LambdaQueryWrapper<Tag> queryWrapper = new LambdaQueryWrapper<>();
        List<Tag> tags=this.tagMapper.selectList(queryWrapper);

        return Result.success(copyList(tags));//为啥要转：就是tag是与数据库映射的对象，tagVo是与前端映射的对象，相当于再次封装
    }

    @Override
    public Result findDetailById(Long id) {
        Tag tag=tagMapper.selectById(id);
        return Result.success(copy(tag));
    }


}
