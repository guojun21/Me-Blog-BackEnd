package com.meblog.blog.controller;


import com.meblog.blog.utils.QiniuUtils;
import com.meblog.blog.vo.Result;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.UUID;

@RestController
@RequestMapping("upload")
public class UploadController {

    @Autowired
    private QiniuUtils qiniuUtils;
    @PostMapping
    public Result upload(@RequestParam("image") MultipartFile file){
        //原始的文件名称 如 aa.png
        String originalFilename = file.getOriginalFilename();
        //唯一的文件名称
        String fileName=UUID.randomUUID().toString()+"."+ StringUtils.substringAfterLast(originalFilename,".");
        //上传图片上传到哪里呢？可以传到应用服务器，但是不好，因为图片占用带宽很大，有可能网络拥塞掉应用服务器，所以要单独来一个图片服务器，虽然也会拥塞，但不会把应用服务器给停掉
        //图片服务器为七牛云
        boolean upload = qiniuUtils.upload(file, fileName);
        if(upload){
            return Result.success(QiniuUtils.url+fileName);
        }
        return Result.fail(20001,"上传失败");


    }
}
