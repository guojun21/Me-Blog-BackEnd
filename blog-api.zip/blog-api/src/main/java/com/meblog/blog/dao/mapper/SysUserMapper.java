package com.meblog.blog.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.meblog.blog.dao.pojo.SysUser;

public interface SysUserMapper extends BaseMapper<SysUser> {

}
